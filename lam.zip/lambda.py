import json
import boto3
import botocore
from datetime import datetime
from aws_requests_auth.aws_auth import AWSRequestsAuth
import requests
from boto3.dynamodb.conditions import Key,Attr
from decimal import Decimal
import os

def applambda(event, context):
    connectionId = event["requestContext"]["connectionId"]
    body = json.loads(event["body"])
    ReceiverID = body["ReceiverID"]
    Msg = body["Msg"]
    MessageDateTime = str(datetime.now().timestamp())
    dynamoConnections = boto3.resource('dynamodb').Table('OnlineConnection')
    resultU = dynamoConnections.scan(FilterExpression=Key('UserID').eq(ReceiverID))
    if(str(Msg).startswith('request-')):
        print("it is a request command")
        
        #get user details from OnlineConnections table
        dynamo = boto3.resource('dynamodb').Table("OnlineConnection")
        users = []
        response = dynamo.scan()
        for i in response['Items']:
            print(i)
            users.append(i)
        Msg = users
        MessageDateTime = 'user-list'
    elif(str(Msg).startswith('search-')):
        print("it is a search command")
        MessageDateTime = 'search-result'

        lambdaClient = boto3.client('lambda')
        payload = Msg
        resp = lambdaClient.invoke(FunctionName="Websocket_checkAvailability", InvocationType="RequestResponse",Payload=json.dumps(payload))
        data = resp['Payload'].read()
        Msg=data
        # code to call searchitem
        # invokeLam = boto3.client("lambda",region_name="us-east-1")
        # payload = Msg[1:-1]
        # resp = invokeLam.invoke(FunctionName = "searchItem", InvocationType = "Event", Payload = json.dumps(payload))

    print("it is a text chat")
    if resultU["Items"] is not None and len(resultU["Items"]) == 1:
        ReceiverConnectionID = resultU["Items"][0]["token"]
        # print("toke is"+ReceiverConnectionID)
        resultX = dynamoConnections.scan(FilterExpression=Key("token").eq(connectionId))
        if resultX["Items"] is not None and len(resultX["Items"]) == 1:
            SenderID = resultX["Items"][0]["UserID"]
            jsonObjToSend = {"MessageID":MessageDateTime,"Message":Msg, "SenderID":SenderID}
            sendDirectMessage(ReceiverConnectionID,jsonObjToSend)
            return {
                "statusCode":200,
                "body":"Msg is delivered"
            }
        else:
            return {
                "statusCode":200,
                "body":"Error Occured"
            }
    else:
        return {
                "statusCode":200,
                "body":"User not online"
            }
def sendDirectMessage(token,jsonobj):
    access_key = os.environ['access_key']
    secret_key = os.environ['secret_key']
    auth  = AWSRequestsAuth(
        aws_access_key=access_key,
        aws_secret_access_key=secret_key,
        aws_host='4shgdlz4ke.execute-api.us-east-1.amazonaws.com',
        # aws_host='https://scn9iooqmd.execute-api.us-east-1.amazonaws.com',
        aws_region='us-east-1',
        aws_service='execute-api'
    )
    print(auth)
    url = 'https://4shgdlz4ke.execute-api.us-east-1.amazonaws.com/dev/%40connections/'+token.replace("=","")+"%3D"
    # https://4shgdlz4ke.execute-api.us-east-1.amazonaws.com/dev/@connections
    print("usr"+url)
    req = requests.post(url, auth=auth, data=str(jsonobj)) 
    print(req.text)
    print(req.status_code)