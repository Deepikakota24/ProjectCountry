
var Data = {};

function validate(){
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var websocketurl = "wss://scn9iooqmd.execute-api.us-east-1.amazonaws.com/dev?userId=".concat(username);
    
    var errormsg = "your account is not registered yet";
    Data.receiver = 'none';
    Data.purchaseStatus = 'notStarted';

    const usernames = ['user1','user2'];

    if(username == '' || password ==''){
        errormsg = "Username and Password shouldn't empyty";
        showError(errormsg);
    }
    else if(usernames.includes(username) && password == "password"){

        Data.ws = new WebSocket(websocketurl);
        Data.ws.addEventListener(
            "open", e =>{
                console.log("We are connected");
                Data.senderID = username;
                addChats();
                displayPage('users','signin');
            }
        );
        Data.ws.addEventListener(
            "close", e =>{
                console.log("We are disconnected");
                location.reload();
                // window.location.href = "users.html";
                displayPage('signin','users');
            }
        );

        Data.ws.addEventListener(
            "message", e =>{
                console.log("message received");
                receiveMessage(e.data);
            }
        );
        return false;
    }
    else{
        // window.alert("failed");
        errormsg = "password is incorrect !"
        showError(errormsg);
    }
}

function sendMessage(){

    var msg = document.getElementById('text-field').value;
    
    if(msg != ''){
        document.getElementById('text-field').value = '';

        //code to display msg on chat
        const div = document.createElement('div');
        div.className = 'chat outgoing';
        div.innerHTML= "<div class='details'><p>"+msg+"</p></div>";
        document.getElementById('chat-box').appendChild(div);
        
        if(msg.startsWith('order-')){
            const div = document.createElement('div');
            div.className = 'chat incoming';
            div.innerHTML= "<div class='details'><p>please enter your address</p></div>";
            document.getElementById('chat-box').appendChild(div);

            Data.purchaseStatus = "itemsReceived";
            //save order items 
        }
        else if(Data.purchaseStatus == "itemsReceived"){
            Data.purchaseStatus = "addressReceived";
            Data.address = msg;
            //save address
            const div = document.createElement('div');
            div.className = 'chat incoming';
            div.innerHTML= "<div class='details'><p>Confirm order(y/n)</p></div>";
            document.getElementById('chat-box').appendChild(div);
        }
        else if(Data.purchaseStatus == "addressReceived"){
            Data.purchaseStatus = "notStarted";
            if(msg == 'y'){
                const div = document.createElement('div');
                div.className = 'chat incoming';
                div.innerHTML= "<div class='details'><p>Order Submitted</p></div>";
                document.getElementById('chat-box').appendChild(div);

                //code to place order
                requestOrder('pen,pencil');
            }
            else{
                const div = document.createElement('div');
                div.className = 'chat incoming';
                div.innerHTML= "<div class='details'><p>Order cancelled !</p></div>";
                document.getElementById('chat-box').appendChild(div);
            }
        }
        else{
            
        if(msg.startsWith("search-")){
            Data.tempReciever = Data.ReceiverID;
            Data.ReceiverID = Data.senderID;
            console.log("changed receiver id"+Data.ReceiverID);
        }
        //code to send msg to websocket
        var str = '\{"Msg":'+'\"'+msg+'\"'+',"ReceiverID":'+'\"'+ Data.ReceiverID+'\"'+',"action":"sendmsg"\}';
        console.log(str);
        Data.ws.send(str);
        // Data.ws.send('{"Msg":'+msg+',"ReceiverID":'+Data.receiver+',"action":"sendmsg"}');
        if(msg.startsWith("search-")){
            Data.ReceiverID = Data.tempReciever;
        }
        }

    }
    return false;
    
}
function receiveMessage(msg){

    
    try {
        //gather message
        var newMsg = msg.replaceAll("\'","\"");
        var newMsg = newMsg.replaceAll("\\","");
        var newMsg = newMsg.replaceAll("\\","");
        var jsonObj = JSON.parse(newMsg);
        var data = jsonObj.Message;
        
        if(msg.includes('user-list')){
            var count = Object.keys(data).length;
            for(var num = 0; num < count ; num++){
                // console.log(data[num]['UserID']);
                if(data[num]['UserID'] != Data.senderID){
                    createChat(data[num]['UserID']);
                }
            }
        }
        else if(msg.includes('search-result')){
            console.log("search response found");
        }
        else if(String(data) != 'undefined'){
            //code to display msg on chat
            const div = document.createElement('div');
            div.className = 'chat incoming';
            div.innerHTML= "<div class='details'><p>"+data+"</p></div>";
            document.getElementById('chat-box').appendChild(div);
        
        }
        console.log("end of try block");
        
        //scroll to latest chat
    } catch(e) {
        console.log(e); // error in the above string (in this case, yes)!
        console.log(newMsg);
        if(newMsg.includes('search-result')){
            // console.log("its is a search result");
            var pattern_1 = "list";
            var pattern_2 = "SenderID";
            var substrg = newMsg.substring(newMsg.indexOf(pattern_1)+8,newMsg.indexOf(pattern_2)-8);
            var avail = substrg.substring(0,substrg.indexOf('-'));
            var nonavail = substrg.substring(substrg.indexOf('-')+1,substrg.length);

            if(avail !=""){
                //code to add available items
                var availBr = avail.replaceAll(",","<br>");
                const div = document.createElement('div');
                div.className = 'chat available';
                div.innerHTML= "<div class=\"details\"><p>"+availBr+"</p></div>";
                document.getElementById('chat-box').appendChild(div);
                Data.purchaseStatus ='itemsAvailable';
            }
            if(nonavail != ""){
                //code to add missing items
                var nonavailBr = nonavail.replaceAll(",","<br>");
                const div = document.createElement('div');
                div.className = 'chat notavailable';
                div.innerHTML= "<div class=\"details\"><p>"+nonavailBr+"</p></div>";
                document.getElementById('chat-box').appendChild(div);
            }
            // const div = document.createElement('div');
            // div.className = 'chat incoming';
            // div.innerHTML= "<div class='details'><p>"+data+"</p></div>";
            // document.getElementById('chat-box').appendChild(div);

            // console.log(substrg);
        }
        //code to handle availability responses

    }
    
    

    return false;
}

function requestOrder(items){

    console.log("sender is" + Data.senderID);
    console.log("Receiver is "+Data.ReceiverID);
    console.log("msg is none");
    console.log("Address is none");
    // var msg = Data.senderID + ' is requsting following items \n'+items;
    // var str = '\{"Msg":'+'\"'+msg+'\"'+',"ReceiverID":'+'\"'+ Data.ReceiverID+'\"'+',"action":"sendmsg"\}';
    // Data.ws.send(str);
}
function addChats(){
    var msg = 'request-';
    var str = '\{"Msg":'+'\"'+msg+'\"'+',"ReceiverID":'+'\"'+ Data.senderID+'\"'+',"action":"sendmsg"\}';
    console.log(str);
    Data.ws.send(str);
    document.getElementById('users-list').innerHTML = "";
}
function createChat(id){
    var  chatBlock = document.getElementById(id);
    if(JSON.stringify(chatBlock) == "null"){
        //chatBlock not exist
        console.log('user not exist');
        const div = document.createElement('div');
        div.className = 'content';
        div.id = id;
        div.innerHTML = '<a href="javascript:void(0);" ><div class="content" onClick="selectUser(this.id)" id='+id+'><img src="img.png" alt=""><div class="details"><span>'+id+'</span><p></p</div></i></div></a>';

        document.getElementById('users-list').appendChild(div);
    }
    
}
function showError(msg){
    document.getElementById('error').textContent = msg;
    document.getElementById('password').value = '';
    document.getElementById('error-txt').style.display = 'block';
    setInterval(removeError,3000);
}
function removeError(){
    document.getElementById('error-txt').style.display = 'none';
}

function displayPage(newPage,oldPage){
    document.getElementById(oldPage).style.display = 'none';
    document.getElementById(newPage).style.display = 'block';
}

function selectUser(rec){
    //add reviver id here
    Data.ReceiverID = rec;
    console.log("id captured_3");
    console.log(Data.ReceiverID);
    document.getElementById('name').textContent = Data.senderID;
    displayPage('chat','users');
}

function getUsers(){
    var str = '\{"action":"sendmsg"\}';
    Data.ws.send(str);
}

function logout(){
    // sendMessage();
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';

    //close websocket connection
    Data.ws.close();
}